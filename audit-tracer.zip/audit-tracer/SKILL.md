---
name: audit-tracer
description: |
  追踪Java Controller接口的完整方法调用链并生成安全审计报告。
  当用户提供Controller文件路径和接口名要求审计、追踪调用链、分析接口安全性时触发。
  支持递归追踪方法调用、识别安全漏洞、生成带代码佐证的审计报告。
tools:
  - Read
  - Grep
  - Glob
  - AskUserQuestion
  - Write
  - Edit
model: sonnet
priority: high
file_patterns:
  - "**/*Controller*.java"
  - "**/*Service*.java"
  - "**/*Impl*.java"
  - "**/*.java"
---

# audit-tracer — 接口调用链追踪审计工具

## When — 触发条件

**必需输入**：
- Controller 文件路径（Java 文件）
- 接口/方法名

**触发模式**：
1. 文件引用模式：`@ControllerFile.java 审计 methodName`
2. 显式命令模式：`追踪 [ControllerFile] 的 [methodName] 接口`
3. 安全审计模式：`对 [ControllerFile] 的 [methodName] 进行安全审计`

**可选输入**：
- Impl 实现类文件路径
- 特定关注点（如：只关注 SQL 注入、只关注文件操作）

## How — 执行流程

### 0. 前置检查

> 优先级：最高，必须在所有步骤之前执行

**检查项**：
1. 验证 Controller 文件是否存在
2. 验证文件是否为 Java 源文件
3. 检查方法名是否存在于 Controller 中
4. 如提供 Impl 文件，验证其存在性

**失败处理**：
- 文件不存在 → 提示用户并提供正确路径建议
- 方法未找到 → 列出 Controller 中所有可用方法供用户选择
- 文件格式错误 → 提示需要 Java 源文件

### 1. 接口定位 + 路径拼接

1. 使用 Grep 在 Controller 文件中查找目标方法
2. 如提供 Impl 文件，使用 Grep 在 Impl 中查找对应实现
3. 读取方法完整代码

**1.1 API 路径拼接（POC 前置步骤，必须执行）**

> 读取 Controller 文件后立即执行，为后续 POC 生成准备完整请求路径

**拼接规则**：
```
完整路径 = 类级别 @RequestMapping 前缀 + 方法级别 mapping 路径
HTTP 方法 = 方法级别注解类型
```

**提取步骤**：
1. 读取 Controller 类上的注解，提取类级别路径前缀：
   - `@RequestMapping("/api/user")` → `/api/user`
   - `@RestController` + 无 @RequestMapping → 前缀为空
   - 注意：Spring 配置文件中的 `server.servlet.context-path` 也需纳入
2. 读取目标方法上的注解，提取方法路径和 HTTP 方法：
   - `@GetMapping("/list")` → GET `/list`
   - `@PostMapping("/save")` → POST `/save`
   - `@PutMapping("/{id}")` → PUT `/{id}`
   - `@DeleteMapping("/{id}")` → DELETE `/{id}`
   - `@RequestMapping(value="/xxx", method=RequestMethod.POST)` → POST `/xxx`
3. 拼接：`{类前缀}{方法路径}` → 例如 `/api/user/save`
4. 解析方法参数，确定请求参数来源：
   - `@RequestBody` → JSON Body 参数
   - `@RequestParam` → Query/String 参数
   - `@PathVariable` → 路径参数
   - `@RequestHeader` → Header 参数
   - `MultipartFile` → 文件上传参数

**输出示例**：
```
接口路径信息：
- 完整路径: POST /api/user/upload
- 类前缀: /api/user (来自 @RequestMapping)
- 方法路径: /upload (来自 @PostMapping)
- 参数来源:
  - file: MultipartFile (文件上传)
  - userId: @RequestParam String (Query参数)
```

### 2. 方法调用扫描

**扫描规则**：
- 本类方法调用：`xxxMethod()`
- 注入服务调用：`xxxService.xxxMethod()`
- 工具类调用：`xxxUtils.xxxMethod()`

**识别要点**：
- 识别 `@Autowired` / `@Resource` 注入的服务
- 记录方法签名和调用参数
- 记录已追踪方法 ID（类名+方法名），避免循环追踪

### 3. 追踪确认（双模式）

**批量确认模式**（首轮推荐）：
1. 展示所有发现的方法调用列表
2. 询问："发现以下 X 个方法调用，是否全部追踪？"
3. 用户选择：
   - 全部追踪 → 递归分析所有方法
   - 跳过全部 → 直接进入安全分析
   - 选择部分 → 仅追踪用户指定的方法

**逐个确认模式**（深度追踪时自动切换）：
对每个子方法调用：
1. 展示完整信息：方法名、所在类、文件路径、行号、调用参数
2. 询问："是否继续追踪 `xxxMethod()`？"
3. 用户确认后递归分析
4. 记录已追踪方法，自动跳过重复项

**深度控制**：
- 默认最大追踪深度：5 层
- 达到深度上限时提示："已达到最大追踪深度(5层)，是否继续？"
- 追踪方法总数上限：50 个（防止分析范围过大）

### 4. 调用链汇总

**输出格式**（树形结构，含行号和状态标记）：

```
upload (UserController.java:23)
├── saveFile (FileService.java:45) [已追踪]
│   ├── writeToDisk (FileService.java:67) [已追踪]
│   │   └── checkDiskSpace (DiskUtils.java:12) [已追踪-安全相关]
│   └── generateFileName (FileService.java:89) [已追踪]
├── validateFile (FileService.java:101) [已追踪]
│   ├── checkExtension (FileValidator.java:23) [已追踪-安全相关]
│   └── sanitizeInput (SecurityUtils.java:45) [已追踪-安全相关]
├── getFileType (FileTypeDetector.java:12) [跳过-纯数据处理]
└── checkPermission (AuthUtils.java:15) [已追踪-安全相关]

统计：共追踪 9 个方法，跳过 1 个纯数据处理工具类
安全相关工具类：3 个（DiskUtils, FileValidator, SecurityUtils, AuthUtils）
```

**确认步骤**：
- 展示完整调用链后
- 询问："已追踪完成，共追踪 X 个方法（跳过 Y 个），是否开始安全分析？"

### 5. 安全分析 + POC 生成

**分析维度**：
- 用户输入校验是否完整（参数校验、类型校验、范围校验）
- 敏感操作安全措施（文件操作、数据库操作、网络请求）
- 常见漏洞模式：SQL 注入、XSS、命令注入、路径遍历、SSRF、XXE、反序列化等
- 业务逻辑安全（越权、重放、竞态条件）
- 认证授权处理（身份验证、权限检查、会话管理）

**代码佐证要求**（每个发现必须满足）：
- 提取问题代码片段（3-10 行上下文）
- 标注代码所在文件路径和行号
- 确保代码片段能够清晰展示安全问题

**严重程度标准**（参考 OWASP Top 10）：
- **高**：可直接导致数据泄露、系统控制或远程代码执行
- **中**：可能导致信息泄露、权限绕过或拒绝服务
- **低**：不直接影响安全性，但存在不规范的编码实践

**POC 生成要求**（每个安全发现必须包含）：

> POC 路径基于步骤 1.1 拼装的完整 API 路径，结合调用链方法参数逐层追溯构造。

**POC 构造流程**：
1. 复用步骤 1.1 已拼接的完整 API 路径
2. 沿调用链向下追溯，收集触发漏洞所需的参数及其传递路径
3. 确定触发漏洞的 HTTP 方法（GET/POST/PUT/DELETE）
4. 根据参数来源（@RequestBody / @RequestParam / @PathVariable / MultipartFile）构造具体请求

**POC 内容要素**：
- **请求路径**：完整的 URL 路径（类前缀 + 方法路径）
- **HTTP 方法**：GET / POST / PUT / DELETE
- **Content-Type**：根据参数类型确定
- **请求参数**：列出触发漏洞所需参数及含义
- **HTTP 请求示例**：浏览器/原始 HTTP 请求格式，可直接用于 Burp Suite 等工具重放
- **预期结果**：漏洞触发后的预期表现

**POC 模板**：

```
#### POC

**请求路径**: POST /api/user/upload
**Content-Type**: multipart/form-data
**参数说明**:
- `file`: 上传文件 (MultipartFile)，漏洞触发点
- `userId`: 用户ID (Query参数)

**HTTP 请求示例**:
POST /api/user/upload?userId=1 HTTP/1.1
Host: <目标域名>
Cookie: JSESSIONID=xxx
Content-Type: multipart/form-data; boundary=----WebKitFormBoundary

------WebKitFormBoundary
Content-Disposition: form-data; name="file"; filename="evil.jsp"
Content-Type: application/octet-stream

<%= Runtime.getRuntime().exec("cmd.exe /c whoami") %>
------WebKitFormBoundary--

**预期结果**: 服务端未校验文件扩展名，evil.jsp 被成功写入可访问目录，
攻击者可通过 /uploads/evil.jsp 直接访问并执行JSP代码。
```

**POC 编写原则**：
- 路径必须来自实际代码中的 mapping 注解，**禁止编造**
- 参数名必须与 Controller 方法参数名一致
- **必须使用浏览器/原始 HTTP 请求格式**（`METHOD /path HTTP/1.1` + `Host: <目标域名>`），**禁止使用 curl 格式**
- Host 头统一使用 `<目标域名>` 占位
- 涉及认证的接口需注明 Cookie 或 Authorization 请求头
- JSON Body 参数直接展示 JSON 原文，GET 请求的 Query 参数拼接在 URL 中
- 文件上传类漏洞需说明上传后的访问路径
- 注入类漏洞需展示典型 payload 的注入位置

### 6. 报告生成

**报告命名**：`{Controller名}-安全审计报告.md`

**报告位置**：与被审计文件相同目录，或用户指定目录

**报告结构模板**：

```markdown
# {Controller名} 安全审计报告

## 审计概览
- 审计时间: {时间}
- 审计接口: {方法名列表}
- 审计人员: AI Assistant

---

## 审计记录 #{序号}

### 接口: {方法名}

#### 调用链

{树形调用链}

统计：共追踪 X 个方法，跳过 Y 个纯数据处理工具类
安全相关工具类：Z 个（列出类名）

#### 安全发现

##### [{严重程度}] {问题标题}
- **位置**: {文件名}:{行号}
- **严重程度**: 高/中/低
- **说明**: {问题描述}
- **代码佐证**:

{问题代码片段（3-10行）}

- **建议**: {修复建议}

##### POC

**请求路径**: {HTTP方法} {完整API路径}
**Content-Type**: {content-type}
**参数说明**:
- `{参数名}`: {参数类型及说明}

**HTTP 请求示例**:
{HTTP方法} {完整API路径}{Query参数拼接} HTTP/1.1
Host: <目标域名>
Cookie: JSESSIONID=<已登录session>
Content-Type: {content-type}
{其他Header如Authorization}

{JSON Body原文 或 multipart表单内容}

**预期结果**: {漏洞触发后的预期表现}
```

**追加模式**：
1. 根据 Controller 文件名查找已存在的报告
2. 存在 → 读取现有报告，在末尾追加新审计记录，更新概览（审计接口数量 +1）
3. 不存在 → 创建新报告

### 7. 性能优化策略

**智能工具类分类处理**：

| 工具类类型 | 处理方式 | 示例 |
|-----------|---------|------|
| 安全相关工具类 | **必须追踪** | SecurityUtils, ValidationUtils, EncryptionUtils, AuthUtils, SanitizeUtils |
| 数据处理工具类 | 询问用户 | StringUtils, DateUtils, NumberUtils, CollectionUtils |
| 框架内置方法 | **跳过追踪** | Spring, MyBatis, Hibernate 内部方法 |

**工具类安全检查清单**（包含以下关键词的工具类必须追踪）：
- `Security`、`Auth`、`Permission`、`Token`
- `Validation`、`Verify`、`Check`
- `Encrypt`、`Decrypt`、`Crypto`、`Hash`
- `Sanitize`、`Filter`、`Escape`、`Clean`
- 任何处理用户输入、权限检查、数据加解密的方法

**缓存机制**：
- 缓存已分析的类文件内容，避免重复读取
- 记录完整追踪路径，支持断点续追

## What — 输出结果

### 正常输出三要素

**1. 调用链可视化**（树形结构，含行号、状态标记和统计信息）

**2. 安全审计报告**（Markdown 文件，生成在指定位置）

**3. 追踪摘要**：
- 追踪方法总数（含跳过数）
- 安全发现数量（按严重程度分类：高/中/低）
- 关键风险点列表

### 异常输出

**追踪失败时**：
```
❌ 追踪失败：无法在 UserController.java 中找到方法 `upload`

该 Controller 中的可用方法：
- getUser (line 15)
- updateUser (line 28)
- deleteUser (line 42)

请确认方法名是否正确后重试。
```

**未发现安全问题时**：
```
✅ 追踪完成：共分析 8 个方法
ℹ️ 未发现明显安全问题

建议：
- 可考虑添加输入参数校验
- 建议增加关键操作日志记录
- 建议定期进行渗透测试验证
```

## 使用示例

### 基础追踪示例

```
用户: @UserController.java @UserServiceImpl.java 审计 upload 接口

Skill 执行:
1. ✓ 前置检查通过
2. ✓ 在 UserController.java 中找到 upload 方法
3. ✓ 在 UserServiceImpl.java 中找到对应实现
4. 分析发现调用了:
   - saveFile(File)
   - validateFile(File)
   - getFileType(String)
5. 询问: "是否全部追踪？"
6. 用户确认后，追踪所有方法调用
7. 递归追踪子方法...
8. 最终形成完整调用链

调用链:
upload
├── saveFile
│   ├── writeToDisk
│   └── checkDiskSpace
├── validateFile
│   ├── checkExtension
│   └── checkSize
└── getFileType

9. 确认后开始安全分析
10. 生成报告: UserController-安全审计报告.md
```

### 追加审计示例

```
用户: @UserController.java 审计 delete 接口

Skill 执行:
1. ✓ 检测到已存在报告: UserController-安全审计报告.md
2. ✓ 定位 delete 方法
3. 追踪调用链: delete → removeById → deleteFromDb → checkPermission
4. 完成安全分析
5. 追加到已有报告

✓ 报告已更新: UserController-安全审计报告.md
  - 新增审计记录 #2
  - 审计接口总数: 2
```

## 最佳实践

### 对于审计人员

**高效审计流程**：
1. 先使用批量确认模式快速追踪主要执行路径
2. 对可疑方法切换逐个确认模式深度追踪
3. 重点关注用户输入处理和数据流转路径

**关注重点优先级**：
1. 用户输入的首次校验点（是否有效、是否完整）
2. 数据库操作前的过滤逻辑（参数化查询、ORM 安全用法）
3. 文件操作的路径验证（路径遍历、扩展名白名单）
4. 网络请求的参数处理（SSRF 防护、URL 白名单）
5. 工具类中的安全防护措施（SecurityUtils、ValidationUtils 的实现质量）

### 对于 Skill 执行

**执行效率**：
- 优先读取小文件（< 100KB）全文，大文件用 Grep 定位后按需读取
- 使用 Grep 正则查找方法调用，不全文读取无关代码
- 缓存已读取的类文件内容，避免重复 I/O

**结果质量保证**：
- 每个安全发现必须有代码佐证（3-10 行上下文）
- 代码片段必须标注完整路径和行号
- 严重程度评估参考 OWASP Top 10 标准
- 修复建议要具体可操作，而非泛泛的"加强校验"

## 关键约束

**必须遵守**：
- 每个安全发现必须包含代码佐证（代码片段 + 路径 + 行号）
- 每个安全发现必须包含 POC（路径必须来自代码中的 mapping 注解，禁止编造）
- POC 路径由 Controller 类级别 @RequestMapping 前缀 + 方法级别 mapping 路径拼接而成
- POC 必须使用浏览器/原始 HTTP 请求格式（`METHOD /path HTTP/1.1` + `Host: <目标域名>`），禁止使用 curl 格式
- 在用户明确确认后才生成安全审计报告
- 安全相关工具类（包含 Security、Auth、Validation 等关键词）必须追踪
- 报告以 Controller 名为单位，支持追加模式

**严格禁止**：
- 禁止循环追踪同一方法（通过"类名:方法名"ID 去重）
- 禁止生成无代码佐证的安全发现
- 禁止生成无 POC 或 POC 路径未取自代码注解的安全发现
- 禁止跳过安全相关工具类的追踪
- 禁止在未确认调用链的情况下直接开始安全分析
