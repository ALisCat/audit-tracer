# audit-tracer — 接口调用链追踪审计工具

## 简介

`audit-tracer` 是一个 Java 代码安全审计 skill，专注于追踪 Controller 接口的完整方法调用链，帮助审计人员在进行安全分析前先梳理清楚代码的执行路径。

## 功能特性

- **前置检查** — 验证文件存在性、方法存在性，失败时智能提示
- **接口定位** — 快速定位 Controller 和 Impl 中的方法定义
- **双模式追踪** — 批量确认（快速模式）+ 逐个确认（深度模式）
- **智能工具类分类** — 自动识别安全相关/数据处理/框架工具类，差异化处理
- **深度控制** — 默认 5 层上限，防止追踪范围失控
- **循环避免** — 通过"类名:方法名"ID 自动去重，避免重复追踪
- **安全分析** — 基于完整调用链进行针对性漏洞分析，强制代码佐证
- **追加报告** — 同一 Controller 多个接口的审计结果自动追加合并

## 使用方式

### 触发模式

| 模式 | 语法 |
|------|------|
| 文件引用 | `@ControllerFile.java @ServiceImpl.java 审计 methodName` |
| 显式命令 | `追踪 [ControllerFile] 的 [methodName] 接口` |
| 安全审计 | `对 [ControllerFile] 的 [methodName] 进行安全审计` |

### 参数说明

| 参数 | 必需 | 说明 |
|------|------|------|
| Controller 文件 | 是 | Controller Java 文件路径 |
| Impl 文件 | 否 | ServiceImpl 文件路径（提供后可追踪实现细节） |
| 方法名 | 是 | 要追踪的接口/方法名 |

### 使用示例

```
用户: /audit-tracer UserController.java UserServiceImpl.java upload
用户: 追踪 UserController 的 upload 接口
用户: 对 UserController.java 的 upload 进行安全审计
```

## 执行流程

```
0. 前置检查 → 验证文件和方法的有效性
1. 接口定位 → 在 Controller/Impl 中定位目标方法
2. 调用扫描 → 提取方法中的所有调用
3. 追踪确认 → 批量/逐个确认，递归追踪子方法
4. 调用链汇总 → 树形展示完整调用路径（含行号、状态标记）
5. 安全分析 → 基于调用链进行 5 维度安全漏洞分析
6. 报告生成 → 生成/追加 Markdown 格式安全审计报告
```

## 输出示例

### 调用链可视化
```
upload (UserController.java:23)
├── saveFile (FileService.java:45) [已追踪]
│   ├── writeToDisk (FileService.java:67) [已追踪]
│   │   └── checkDiskSpace (DiskUtils.java:12) [已追踪-安全相关]
│   └── generateFileName (FileService.java:89) [已追踪]
├── validateFile (FileService.java:101) [已追踪]
│   ├── checkExtension (FileValidator.java:23) [已追踪-安全相关]
│   └── sanitizeInput (SecurityUtils.java:45) [已追踪-安全相关]
└── checkPermission (AuthUtils.java:15) [已追踪-安全相关]

统计：共追踪 9 个方法，跳过 1 个纯数据处理工具类
安全相关工具类：3 个
```

### 安全审计报告
```
报告文件: UserController-安全审计报告.md
格式: Markdown，含审计概览、调用链、安全发现（带代码佐证）、修复建议
```

## 适用场景

- 安全审计前的代码执行路径梳理
- 理解复杂业务逻辑的完整调用关系
- 追踪敏感操作（文件上传、数据库操作、网络请求）的完整路径
- 识别潜在攻击面及防护薄弱点

## 注意事项

- 本 skill 针对 Java/Spring 项目
- 需要提供正确的 Controller 文件路径
- 安全分析基于代码模式识别，建议结合人工复核
- 报告生成在与被审计文件相同目录下
